// admin-productos.js
function guardarProducto(formData) {
  const productos = JSON.parse(localStorage.getItem('bratzProductos')) || [];
  const existing = productos.find(p => p.id === formData.id);
  if (existing) {
    // editar
    Object.assign(existing, formData);
  } else {
    productos.push(formData);
  }
  localStorage.setItem('bratzProductos', JSON.stringify(productos));
  alert('Producto guardado.');
}
function eliminarProducto(id) {
  let productos = JSON.parse(localStorage.getItem('bratzProductos')) || [];
  productos = productos.filter(p => p.id !== id);
  localStorage.setItem('bratzProductos', JSON.stringify(productos));
  renderProductosAdmin();
}
function renderProductosAdmin() {
  const cont = document.getElementById('adminListaProductos');
  const productos = JSON.parse(localStorage.getItem('bratzProductos')) || [];
  cont.innerHTML = '';
  productos.forEach(p => {
    cont.innerHTML += `<div class="d-flex justify-content-between align-items-center py-2 border-bottom">
      <div><strong>${p.id}</strong> - ${p.nombre} - $${p.precio.toLocaleString('es-CL')}</div>
      <div>
        <button class="btn btn-sm btn-outline-light" onclick="editarProducto('${p.id}')">Editar</button>
        <button class="btn btn-sm btn-outline-danger" onclick="eliminarProducto('${p.id}')">Eliminar</button>
      </div>
    </div>`;
  });
}
