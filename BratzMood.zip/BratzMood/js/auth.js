document.getElementById("loginForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  // Credenciales de administrador
  if (email === "admin@admin.com" && password === "admin123") {
    localStorage.setItem("rol", "admin");
    window.location.href = "admin.html";
  } else {
    localStorage.setItem("rol", "user");
    window.location.href = "index.html";
  }
});

function logout() {
  localStorage.removeItem("rol");
  window.location.href = "login.html";
}
