// =========================
// ADMIN - Gestión Productos
// =========================

// Recuperar lista de productos o crear vacía
let productos = JSON.parse(localStorage.getItem("bratzProductos")) || [];

// Referencias a elementos
const productoForm = document.getElementById("productoForm");
const listaProductos = document.getElementById("listaProductos");
const imgFileInput = document.getElementById("imgFile");

// =========================
// Guardar producto
// =========================
productoForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const nombre = document.getElementById("nombre").value.trim();
  const descripcion = document.getElementById("descripcion").value.trim();
  const precio = parseFloat(document.getElementById("precio").value);
  const imgFile = imgFileInput.files[0];

  if (!nombre || !descripcion || !precio || !imgFile) {
    alert("Por favor completa todos los campos");
    return;
  }

  const reader = new FileReader();
  reader.onload = function (event) {
    const nuevoProducto = {
      id: Date.now().toString(),
      nombre,
      descripcion,
      precio,
      img: event.target.result // imagen en base64
    };

    productos.push(nuevoProducto);
    localStorage.setItem("bratzProductos", JSON.stringify(productos));

    productoForm.reset();
    document.getElementById("preview").style.display = "none";
    renderProductos();
  };
  reader.readAsDataURL(imgFile);
});

// =========================
// Renderizar lista productos
// =========================
function renderProductos() {
  listaProductos.innerHTML = "";

  if (productos.length === 0) {
    listaProductos.innerHTML = `<p class="text-center text-light">No hay productos registrados todavía.</p>`;
    return;
  }

  productos.forEach((p) => {
    listaProductos.innerHTML += `
      <div class="col">
        <div class="card h-100 bg-black text-light border-pink shadow">
          <img src="${p.img}" class="card-img-top" alt="${p.nombre}">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title text-pink">${p.nombre}</h5>
            <p class="card-text">${p.descripcion}</p>
            <p class="fw-bold text-pink">$${p.precio.toLocaleString("es-CL")} CLP</p>
            <button class="btn btn-outline-danger mt-auto" onclick="eliminarProducto('${p.id}')">
              Eliminar
            </button>
          </div>
        </div>
      </div>
    `;
  });
}

// =========================
// Eliminar producto
// =========================
function eliminarProducto(id) {
  if (confirm("¿Seguro que quieres eliminar este producto?")) {
    productos = productos.filter((p) => p.id !== id);
    localStorage.setItem("bratzProductos", JSON.stringify(productos));
    renderProductos();
  }
}

// =========================
// ADMIN - Gestión Usuarios
// =========================

// Recuperar lista de usuarios o crear vacía
let usuarios = JSON.parse(localStorage.getItem("bratzUsuarios")) || [];

// Guardar en localStorage
function guardarUsuarios() {
  localStorage.setItem("bratzUsuarios", JSON.stringify(usuarios));
}

// Renderizar tabla de usuarios
function mostrarUsuarios() {
  const lista = document.getElementById("listaUsuarios");
  if (!lista) return; // seguridad por si no existe en la página

  if (usuarios.length === 0) {
    lista.innerHTML = `<p class="text-center text-secondary">No hay usuarios registrados.</p>`;
    return;
  }

  let tabla = `
    <div class="table-responsive">
      <table class="table table-dark table-striped table-bordered align-middle">
        <thead class="table-pink text-light">
          <tr>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
  `;

  usuarios.forEach((u, index) => {
    tabla += `
      <tr>
        <td>${u.nombre}</td>
        <td>${u.correo}</td>
        <td>
          <button class="btn btn-sm btn-outline-light me-2" onclick="editarUsuario(${index})">✏ Editar</button>
          <button class="btn btn-sm btn-outline-danger" onclick="eliminarUsuario(${index})">🗑 Eliminar</button>
        </td>
      </tr>
    `;
  });

  tabla += `
        </tbody>
      </table>
    </div>
  `;

  lista.innerHTML = tabla;
}

// Agregar usuario
const usuarioForm = document.getElementById("usuarioForm");
if (usuarioForm) {
  usuarioForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const nombre = document.getElementById("nombreUsuario").value.trim();
    const correo = document.getElementById("correoUsuario").value.trim();
    const password = document.getElementById("passwordUsuario").value.trim();

    if (!nombre || !correo || !password) {
      alert("Por favor completa todos los campos de usuario.");
      return;
    }

    usuarios.push({ nombre, correo, password });
    guardarUsuarios();
    mostrarUsuarios();

    this.reset();
  });
}

// Eliminar usuario
function eliminarUsuario(index) {
  if (confirm("¿Seguro que quieres eliminar este usuario?")) {
    usuarios.splice(index, 1);
    guardarUsuarios();
    mostrarUsuarios();
  }
}

// Editar usuario
function editarUsuario(index) {
  const usuario = usuarios[index];
  document.getElementById("nombreUsuario").value = usuario.nombre;
  document.getElementById("correoUsuario").value = usuario.correo;
  document.getElementById("passwordUsuario").value = usuario.password;

  eliminarUsuario(index); // se eliminará y luego al guardar se agrega actualizado
}

// =========================
// Cerrar sesión
// =========================
function logout() {
  localStorage.removeItem("usuarioActivo");
  window.location.href = "login.html"; // Ajusta si tu login tiene otro nombre
}

// Render inicial
renderProductos();
mostrarUsuarios();
