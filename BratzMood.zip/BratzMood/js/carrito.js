let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
const carritoLista = document.getElementById('carrito-lista');
const carritoTotal = document.getElementById('carrito-total');

function renderCarrito() {
  if (!carritoLista) return; // evita errores si no estamos en carrito.html
  carritoLista.innerHTML = '';
  let total = 0;

  if (carrito.length === 0) {
    carritoLista.innerHTML = `<p class="text-center text-light">Tu carrito está vacío 😢</p>`;
    if(carritoTotal) carritoTotal.textContent = '0';
    return;
  }

  carrito.forEach((item, index) => {
    total += item.precio * item.cantidad;
    const div = document.createElement('div');
    div.classList.add('cart-item','d-flex','justify-content-between','align-items-center');
    div.innerHTML = `
      <div>
        <h5 class="text-pink mb-1">${item.nombre}</h5>
        <p class="mb-0">Cantidad: ${item.cantidad}</p>
        <p class="mb-0">Precio: $${item.precio}</p>
      </div>
      <button class="btn btn-remove btn-sm" onclick="eliminarProducto(${index})">Eliminar</button>
    `;
    carritoLista.appendChild(div);
  });

  if(carritoTotal) carritoTotal.textContent = total;
}
function mostrarNotificacion(mensaje) {
  const notif = document.getElementById('notif');
  if (!notif) return;
  notif.textContent = mensaje;
  notif.style.display = 'block';
  setTimeout(() => {
    notif.style.display = 'none';
  }, 2000); // desaparece después de 2 segundos
}

function agregarAlCarrito(id, cantidad) {
  const productos = JSON.parse(localStorage.getItem('bratzProductos')) || [];
  const producto = productos.find(p => p.id === id);
  if (!producto) return;

  const index = carrito.findIndex(item => item.id === id);
  if (index >= 0) {
    carrito[index].cantidad += cantidad;
  } else {
    carrito.push({ ...producto, cantidad });
  }

  localStorage.setItem('carrito', JSON.stringify(carrito));
  renderCarrito();

  // Mostrar notificación
  mostrarNotificacion(`${producto.nombre} agregado 💖`);
}
// Función eliminar producto
function eliminarProducto(index) {
  carrito.splice(index, 1);
  localStorage.setItem('carrito', JSON.stringify(carrito));
  renderCarrito();
}

// Ejecutar render al cargar la página
renderCarrito();
