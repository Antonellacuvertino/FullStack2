// products-data: id único, nombre, descripcion, precio (CLP), img, categoria, stock, tallas, uso
const productos = [
  {
    id: "P001",
    nombre: "CAT EYES",
    descripcion: "Dos cajas de pestañas postizas de media longitud, naturales y esponjosas.",
    precio: 4000,
    img: "img/producto1.png",
    categoria: "pestañas",
    stock: 50,
    tallas: [],
    uso: "Se utilizan con pegamento Bond and Seal (adhesivo + sellado) para un acabado natural."
  },
  {
    id: "P002",
    nombre: "Pestañas Glam",
    descripcion: "Set de pestañas largas y llamativas, perfectas para un look Bratz gótico.",
    precio: 5500,
    img: "img/producto2.png",
    categoria: "pestañas",
    stock: 40,
    tallas: [],
    uso: "Aplicar pelo a pelo con pegamento y sellado para mayor duración."
  },
  {
    id: "P003",
    nombre: "Zapatos góticos Mary Janes",
    descripcion: "Zapatos de plataforma con correa en el tobillo, punta redonda y fondo grueso.",
    precio: 50000,
    img: "img/producto3.png",
    categoria: "zapatos",
    stock: 10,
    tallas: ["36", "37", "38", "39"],
    uso: "Calzado de uso diario o para eventos, estilo alternativo Bratz."
  }
];

// Guardar productos iniciales en localStorage (solo si no existen)
if (!localStorage.getItem('bratzProductos')) {
  localStorage.setItem('bratzProductos', JSON.stringify(productos));
}

];

// Guardar productos iniciales en localStorage (solo si no existen)
if (!localStorage.getItem('bratzProductos')) {
  localStorage.setItem('bratzProductos', JSON.stringify(productos));
}
