// ============================
// validaciones.js
// ============================

// valida emails permitidos (duoc.cl, profesor.duoc.cl, gmail.com)
function emailPermitido(email) {
  if (!email) return false;
  const domain = email.split('@')[1] || '';
  const allowed = ['duoc.cl', 'profesor.duoc.cl', 'gmail.com'];
  return allowed.includes(domain.toLowerCase()) && email.length <= 100;
}

// ============================
// Login validator
// ============================
function validarLogin({ email, password }) {
  const result = { valid: true, email: true, password: true };

  if (!emailPermitido(email)) {
    result.email = false;
    result.valid = false;
  }
  if (!password || password.length < 4 || password.length > 10) {
    result.password = false;
    result.valid = false;
  }
  return result;
}

// ============================
// Registro de usuario
// ============================
function validarRegistro(data) {
  const r = {
    valid: true,
    run: true,
    nombre: true,
    apellidos: true,
    correo: true,
    direccion: true,
    password: true
  };

  // run: solo dígitos + K opcional, sin puntos ni guion, min 7 max 9
  if (!/^[0-9Kk]{7,9}$/.test(data.run)) {
    r.run = false; r.valid = false;
  }
  if (!data.nombre || data.nombre.length > 50) {
    r.nombre = false; r.valid = false;
  }
  if (!data.apellidos || data.apellidos.length > 100) {
    r.apellidos = false; r.valid = false;
  }
  if (!emailPermitido(data.correo)) {
    r.correo = false; r.valid = false;
  }
  if (!data.direccion || data.direccion.length > 300) {
    r.direccion = false; r.valid = false;
  }
  if (!data.password || data.password.length < 4 || data.password.length > 10) {
    r.password = false; r.valid = false;
  }
  return r;
}

// ============================
// Checkout simple
// ============================
function validarCheckout({ nombre, email, direccion }) {
  return {
    valid: Boolean(nombre) && emailPermitido(email) && Boolean(direccion),
    nombre: Boolean(nombre) && nombre.length <= 100,
    email: emailPermitido(email),
    direccion: Boolean(direccion) && direccion.length <= 300
  };
}

// ============================
// Eventos para login / registro
// ============================

// Registro: guarda usuario en localStorage
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = {
      run: document.getElementById("registerRun").value,
      nombre: document.getElementById("registerName").value,
      apellidos: document.getElementById("registerLastname").value,
      correo: document.getElementById("registerEmail").value,
      direccion: document.getElementById("registerAddress").value,
      password: document.getElementById("registerPassword").value
    };

    const valid = validarRegistro(data);
    if (valid.valid) {
      localStorage.setItem("user", JSON.stringify({ email: data.correo, password: data.password }));
      alert("Registro exitoso, ahora puedes iniciar sesión.");
      // Cambiar a tab de login automáticamente
      document.querySelector('[data-bs-target="#login"]').click();
    } else {
      alert("Datos inválidos en el registro, revisa los campos.");
    }
  });
}

// Login: valida credenciales y redirige
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = {
      email: document.getElementById("loginEmail").value,
      password: document.getElementById("loginPassword").value
    };

    const valid = validarLogin(data);
    if (!valid.valid) {
      alert("Datos de login inválidos.");
      return;
    }

    const user = JSON.parse(localStorage.getItem("user"));
    if (user && user.email === data.email && user.password === data.password) {
      window.location.href = "productos.html";
    } else {
      alert("Usuario o contraseña incorrectos.");
    }
  });
}
